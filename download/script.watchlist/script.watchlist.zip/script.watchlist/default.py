#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import xbmc
import xbmcplugin
import xbmcaddon
import xbmcgui
from traceback import print_exc
from time import gmtime, strftime

if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson

__addon__        = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__      = __addon__.getAddonInfo('id')
__addonname__    = __addon__.getAddonInfo('name')
__localize__     = __addon__.getLocalizedString
__datapath__     = os.path.join( xbmc.translatePath( "special://profile/addon_data/" ).decode('utf-8'), __addonid__ )
PLOT_ENABLE = True

def log(txt):
    message = '%s: %s' % (__addonname__, txt.encode('ascii', 'ignore'))
    xbmc.log(msg=message, level=xbmc.LOGDEBUG)

class Main:
    def __init__(self):
        self._parse_argv()
            
        full_liz = list()
        
        if self.TYPE == "movies":
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
            self.movies( full_liz )
        elif self.TYPE == "episodes":
            xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
            self.episodes( full_liz)
            
        elif not self.TYPE:
            # Show a root menu
            items = [[32001, "movies"], [32002, "episodes"]]
            for item in items:
                liz = xbmcgui.ListItem( __localize__( item[0] ) )
                liz.setIconImage( "DefaultFolder.png" )
                xbmcplugin.addDirectoryItem( int(sys.argv[1]), "plugin://script.watchlist?type=" + item[1], liz, True )
        else:
            # Unsupported type variable
            log( "Unsupported media type" )
            pass
        
        xbmcplugin.endOfDirectory(handle= int(sys.argv[1]), cacheToDisc = False)
                        
    def movies( self, full_liz ):
        xbmcplugin.setContent( int( sys.argv[1] ), "movies" )

        # Get movies watchlist
        json_string = '{"jsonrpc": "2.0",  "id": 1, "method": "VideoLibrary.GetMovies", "params": {"properties": ["title", "originaltitle", "votes", "playcount", "year", "genre", "studio", "country", "tagline", "plot", "runtime", "file", "plotoutline", "lastplayed", "trailer", "rating", "resume", "art", "streamdetails", "mpaa", "director"], "limits": {"end": %d},' % self.LIMIT
        json_query = xbmc.executeJSONRPC('%s "sort": {"order": "descending", "method": "lastplayed"}, "filter": {"field": "inprogress", "operator": "true", "value": ""}}}' %json_string)
        json_query = unicode(json_query, 'utf-8', errors='ignore')
        json_query = simplejson.loads( json_query )
        
        # Check whether results have been returned
        if json_query.has_key( "result" ) and json_query[ "result" ].has_key( "movies" ):
            for item in json_query[ "result" ][ "movies" ]:
                liz = xbmcgui.ListItem( item[ "title" ] )
                
                # Check watched status, and set plot (if plot enabled)
                watched = False
                if item[ "playcount" ] >= 1:
                    watched = True
                if not PLOT_ENABLE and not watched:
                    plot = __localize__( 32003 )
                else:
                    plot = item[ "plot" ]
                    
                if len( item[ 'studio' ] ) > 0:
                    studio = item[ 'studio' ][ 0 ]
                else:
                    studio = ""
                if len( item[ 'country' ] ) > 0:
                    country = item[ 'country' ][ 0 ]
                else:
                    country = ""
                    
                # Item details
                liz.setInfo( type="Video", infoLabels={ "Title": item['title'] })
                liz.setInfo( type="Video", infoLabels={ "OriginalTitle": item['originaltitle'] })
                liz.setInfo( type="Video", infoLabels={ "Year": item['year'] })
                liz.setInfo( type="Video", infoLabels={ "Genre": " / ".join(item['genre']) })
                liz.setInfo( type="Video", infoLabels={ "Studio": studio })
                liz.setInfo( type="Video", infoLabels={ "Country": country })
                liz.setInfo( type="Video", infoLabels={ "Plot": plot })
                liz.setInfo( type="Video", infoLabels={ "PlotOutline": item['plotoutline'] })
                liz.setInfo( type="Video", infoLabels={ "Tagline": item['tagline'] })
                liz.setInfo( type="Video", infoLabels={ "Rating": str(float(item['rating'])) })
                liz.setInfo( type="Video", infoLabels={ "Votes": item['votes'] })
                liz.setInfo( type="Video", infoLabels={ "MPAA": item['mpaa'] })
                liz.setInfo( type="Video", infoLabels={ "Director": " / ".join(item['director']) })
                liz.setInfo( type="Video", infoLabels={ "Trailer": item['trailer'] })
                liz.setInfo( type="Video", infoLabels={ "Playcount": item['playcount'] })
                liz.setProperty("resumetime", str(item['resume']['position']))
                liz.setProperty("totaltime", str(item['resume']['total']))
                #liz.setProperty("type", __localize__(list_type))
                
                # Art
                liz.setArt(item['art'])
                liz.setThumbnailImage(item['art'].get('poster', ''))
                liz.setIconImage('DefaultVideoCover.png')
                liz.setProperty("fanart_image", item['art'].get('fanart', ''))
                
                # Stream details
                for key, value in item['streamdetails'].iteritems():
                    for stream in value:
                        liz.addStreamInfo( key, stream ) 
                # Add item to list
                
                xbmcplugin.addDirectoryItem( int(sys.argv[1]), item[ "file" ], liz, False, self.LIMIT)
    
    def episodes( self, full_liz ):
        xbmcplugin.setContent( int( sys.argv[1] ), "episodes" )
        
        dateCompare = []
        dateAdded = []
        listNew = []
        
        if __addon__.getSetting("next_unwatched")  == 'false':
            # Get first episode of in progress
            json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties": ["title", "studio", "mpaa", "file", "art", "lastplayed"], "sort": {"order": "descending", "method": "lastplayed"}, "filter": {"field": "inprogress", "operator": "true", "value": ""}, "limits": {"end": %d}}, "id": 1}' %self.LIMIT)
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('tvshows'):
                for item in json_query['result']['tvshows']:
                    # If we've been told to abort, do so
                    if xbmc.abortRequested:
                        break
                        
                    dateCompare.append( item[ "lastplayed" ] )
                        
                    # Get details of this particular episode
                    json_query2 = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"tvshowid": %d, "properties": ["title", "playcount", "plot", "season", "episode", "showtitle", "file", "lastplayed", "rating", "resume", "art", "streamdetails", "firstaired", "runtime"], "sort": {"method": "episode"}, "filter": {"field": "playcount", "operator": "is", "value": "0"}, "limits": {"end": 1}}, "id": 1}' %item['tvshowid'])
                    json_query2 = simplejson.loads( json_query2 )
                    
                    if json_query2.has_key( "result" ) and json_query2[ "result" ] is not None and json_query2[ "result" ].has_key( "episodes" ):
                        for item2 in json_query2[ "result" ][ "episodes" ]:
                            liz = self._parse_episode( item2, item[ "mpaa" ] )
                            # Add item to list
                            full_liz.append( (liz[0], liz[1], False) )
                            if __addon__.getSetting("new_unwatched")  == 'false':
                                xbmcplugin.addDirectoryItem( int(sys.argv[1]), liz[0], liz[1], False, self.LIMIT)
                            
        else:
            # Get next episode of in progress
            json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties": ["title", "studio", "mpaa", "file", "art", "lastplayed"], "sort": {"order": "descending", "method": "lastplayed"}, "filter": {"field": "inprogress", "operator": "true", "value": ""}, "limits": {"end": %d}}, "id": 1}' %self.LIMIT)
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('tvshows'):
                for item in json_query['result']['tvshows']:
                    # If we've been told to abort, do so
                    if xbmc.abortRequested:
                        break
                        
                    dateCompare.append( item[ "lastplayed" ] )
                        
                    # Get details of all episodes
                    json_query2 = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"tvshowid": %d, "properties": ["title", "playcount", "plot", "season", "episode", "showtitle", "file", "lastplayed", "rating", "resume", "art", "streamdetails", "firstaired", "runtime"], "sort": {"method": "episode", "order": "descending"}}, "id": 1}' %item['tvshowid'])
                    json_query2 = simplejson.loads( json_query2 )
                    
                    watchedDate = None
                    choice1 = None
                    choice2 = None
                    # Find the first unwatched episode after the last watched
                    if json_query2.has_key( "result" ) and json_query2[ "result" ] is not None and json_query2[ "result" ].has_key( "episodes" ):
                        for item2 in json_query2[ "result" ][ "episodes" ]:
                            if item2[ "playcount" ] == 0:
                                # An unwatched episode
                                choice2 = item2
                            else:
                                # A watched episode
                                if watchedDate is None or watchedDate < item2[ "lastplayed" ]:
                                    watchedDate = item2[ "lastplayed" ]
                                    if choice2 is not None:
                                        choice1 = choice2
                    
                        if choice1 is not None:
                            item2 = choice1
                        else:
                            item2 = choice2
                        
                        liz = self._parse_episode( item2, item[ "mpaa" ] )
                        full_liz.append( (liz[0], liz[1], False ) )
                        if __addon__.getSetting("new_unwatched")  == 'false':
                            xbmcplugin.addDirectoryItem( int(sys.argv[1]), liz[0], liz[1], False, self.LIMIT)
        
        if __addon__.getSetting("new_unwatched")  == 'true':
            # Get first episode of new shows
            json_query = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetTVShows", "params": {"properties": ["title", "studio", "mpaa", "file", "art", "dateadded"], "sort": {"order": "descending", "method": "dateadded"}, "filter": {"field": "inprogress", "operator": "false", "value": ""}, "limits": {"end": %d}}, "id": 1}' %self.LIMIT)
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('tvshows'):
                for item in json_query['result']['tvshows']:
                    # If we've been told to abort, do so
                    if xbmc.abortRequested:
                        break
                        
                    dateAdded.append( item[ "dateadded" ] )
                    # Get details of this particular episode
                    json_query2 = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetEpisodes", "params": {"tvshowid": %d, "properties": ["title", "playcount", "plot", "season", "episode", "showtitle", "file", "lastplayed", "rating", "resume", "art", "streamdetails", "firstaired", "runtime", "dateadded"], "sort": {"method": "episode"}, "filter": {"field": "playcount", "operator": "is", "value": "0"}, "limits": {"end": 1}}, "id": 1}' %item['tvshowid'])
                    json_query2 = simplejson.loads( json_query2 )
                    
                    if json_query2.has_key( "result" ) and json_query2[ "result" ] is not None and json_query2[ "result" ].has_key( "episodes" ):
                        for item2 in json_query2[ "result" ][ "episodes" ]:
                            liz = self._parse_episode( item2, item[ "mpaa" ] )
                            listNew.append( (liz[0], liz[1], False ) )

            # Combine lists
            log( "### Comparing dates..." )
            if len( listNew ) is not 0:
                count = 0
                for compare in dateCompare:
                    while dateAdded[0] > compare:
                        # Insert it above the item we're comparing
                        log( "Inserted " + dateAdded[0] + " before " + compare + " (at " + str( count ) + ")" )
                        full_liz.insert(count, listNew[0] )
                        listNew.pop( 0 )
                        dateAdded.pop( 0 )
                        count += 1
                        
                        if len( dateAdded ) == 0:
                            break
                        if count > self.LIMIT:
                            break
                            log( "### Count greater than limit, breaking")
                    count += 1
                    if count > self.LIMIT:
                        log( "### Count greater than limit, breaking" )
                        break
                    
            if len( listNew ) is not 0:
                # Add any remaining items, in order
                for item in listNew:
                    full_liz.append( item )
                    
            log( "### Total items: " + str( len( full_liz ) ) )
            xbmcplugin.addDirectoryItems( int(sys.argv[1]), full_liz[:self.LIMIT], self.LIMIT)

    def _parse_episode( self, item, mpaa ):
        liz = xbmcgui.ListItem( item[ "title" ] )
        
        # Episode/season details
        episode = "%.2d" % float(item['episode'])
        season = "%.2d" % float(item['season'])
        episodeno = "s%se%s" %(season,episode)
        
        if "studio" in item:
            if len( item[ 'studio' ] ) > 0:
                studio = item[ 'studio' ][ 0 ]
            else:
                studio = ""
        else:
            studio = ""
        
        # Check watched status and set plot (if plot enabled)
        watched = False
        if item[ "playcount" ] >= 1:
            watched = True
        if not PLOT_ENABLE and not watched:
            plot = __localize__( 32003 )
        else:
            plot = item[ "plot" ]
            
        # Item details
        liz.setInfo( type="Video", infoLabels={ "Title": item['title'] })
        liz.setInfo( type="Video", infoLabels={ "Episode": item['episode'] })
        liz.setInfo( type="Video", infoLabels={ "Season": item['season'] })
        liz.setInfo( type="Video", infoLabels={ "Studio": studio })
        liz.setInfo( type="Video", infoLabels={ "Premiered": item['firstaired'] })
        liz.setInfo( type="Video", infoLabels={ "Plot": plot })
        liz.setInfo( type="Video", infoLabels={ "TVshowTitle": item['showtitle'] })
        liz.setInfo( type="Video", infoLabels={ "Rating": str(round(float(item['rating']),1)) })
        liz.setInfo( type="Video", infoLabels={ "MPAA": mpaa })
        liz.setInfo( type="Video", infoLabels={ "Playcount": item['playcount'] })
        liz.setProperty("episodeno", episodeno)
        liz.setProperty("resumetime", str(item['resume']['position']))
        liz.setProperty("totaltime", str(item['resume']['total']))
        
        # Art
        liz.setArt(item['art'])
        liz.setThumbnailImage(item['art'].get('thumb',''))
        liz.setIconImage('DefaultTVShows.png')
        liz.setProperty("fanart_image", item['art'].get('tvshow.fanart',''))
        
        # Stream details
        for key, value in item['streamdetails'].iteritems():
            for stream in value:
                liz.addStreamInfo( key, stream ) 
        
        return ( item[ "file" ], liz )
            
    def _parse_argv( self ):
        try:
            params = dict( arg.split( "=" ) for arg in sys.argv[ 2 ].split( "&" ) )
        except:
            params = {}
        self.LIMIT = int(__addon__.getSetting("limit"))
        self.TYPE = params.get( "?type", "" )
        global PLOT_ENABLE 
        PLOT_ENABLE = __addon__.getSetting("plot_enable")  == 'true'
    
log('script version %s started' % __addonversion__)
Main()
log('script version %s stopped' % __addonversion__)