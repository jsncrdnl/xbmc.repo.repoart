ART -reFocus for XBMC
============

A mod of the XBMC Refocus Gotham skin where new views and options were added to give a more pleasing design, especially for (fanart, poster, landscape etc.  You can also find into the forum

http://forum.xbmc.org/showthread.php?tid=193135

license: http://creativecommons.org/licenses/by-nc-sa/3.0/
